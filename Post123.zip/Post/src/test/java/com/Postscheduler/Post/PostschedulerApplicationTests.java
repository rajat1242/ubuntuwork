package com.Postscheduler.Post;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostschedulerApplicationTests {

	@Test
	void contextLoads() {
	}

}
