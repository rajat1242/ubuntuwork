package com.Postscheduler.Post;

import org.springframework.scheduling.annotation.Async;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class NetworkDiscoveryTask implements Task {
    private final String apiUrl;

    public NetworkDiscoveryTask() {
        // Replace with your API URL
        this.apiUrl = "https://your-api-endpoint.com";
    }

    @Override

    @Async("customTaskExecutor")
    public void run() {


        try {
            // Create a URL object with your API URL
            URL url = new URL(apiUrl);

            // Open a connection to the URL
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            // Set the request method to POST
            connection.setRequestMethod("POST");

            // Enable input/output streams
            connection.setDoOutput(true);

            // Send the POST request
            OutputStream os = connection.getOutputStream();
            os.flush();
            os.close();

            // Get the response code (you can also read the response content if needed)
            int responseCode = connection.getResponseCode();
            System.out.println("API Response Code: " + responseCode);

            // Close the connection
            connection.disconnect();

            // Simulate the completion of network discovery
            System.out.println("Network Discovery Task completed.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
