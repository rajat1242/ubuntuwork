package com.Postscheduler.Post;

public interface Task {
    void run();
}



