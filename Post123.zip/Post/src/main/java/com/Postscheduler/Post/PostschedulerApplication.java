package com.Postscheduler.Post;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.util.concurrent.TimeUnit;

@SpringBootApplication
@EnableScheduling
public class PostschedulerApplication {

	public static void main(String[] args) {

		TaskExecutor taskExecutor = new TaskExecutor();

		// Create a new NetworkDiscoveryTask
		NetworkDiscoveryTask networkDiscoveryTask = new NetworkDiscoveryTask();

		ReservationRelease ReservationRelease = new ReservationRelease();

		// Submit the task to run every 24 hours
		taskExecutor.submitTask(networkDiscoveryTask, 0, 24, TimeUnit.HOURS);

		taskExecutor.submitTask( ReservationRelease, 0, 15, TimeUnit.MINUTES);

		// Shutdown the executor when it's no longer needed
		// taskExecutor.shutdown();




		SpringApplication.run(PostschedulerApplication.class, args);
	}

}
