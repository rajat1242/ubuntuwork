package com.Postscheduler.Post;


import java.util.concurrent.Executors;
        import java.util.concurrent.ScheduledExecutorService;
        import java.util.concurrent.TimeUnit;

public class TaskExecutor {
    private final ScheduledExecutorService executorService;

    public TaskExecutor() {
        // Create a single-threaded ScheduledExecutorService
        this.executorService = Executors.newSingleThreadScheduledExecutor();
    }

    public void submitTask(Task task, long initialDelay, long period, TimeUnit timeUnit) {
        // Schedule the task with initial delay and fixed rate
        executorService.scheduleAtFixedRate(task::run, initialDelay, period, timeUnit);
    }

    public void shutdown() {
        // Shutdown the executor when it's no longer needed
        executorService.shutdown();
    }
}
