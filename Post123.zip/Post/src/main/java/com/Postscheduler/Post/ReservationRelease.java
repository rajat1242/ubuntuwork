package com.Postscheduler.Post;

import org.springframework.scheduling.annotation.Async;

public class ReservationRelease implements Task {
    private long releaseTime;
    private String orderId;

    public ReservationRelease() {
        this.releaseTime = releaseTime;
        this.orderId = orderId;
    }

    @Override
    @Async("customTaskExecutor")
    public void run() {
        // Implement your reservation release logic here
        System.out.println("Running Reservation Release Task for Order ID: " + orderId);
    }
}